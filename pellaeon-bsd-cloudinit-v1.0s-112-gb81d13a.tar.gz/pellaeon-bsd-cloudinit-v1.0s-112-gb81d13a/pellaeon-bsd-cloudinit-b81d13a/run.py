from cloudbaseinit import shell

shell.main()
